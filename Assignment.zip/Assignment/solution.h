#include <bits/stdc++.h>
#include <iostream>
using namespace std;
class Maximum{
    public:
    int maxProfit(vector<int> price, int k);

};