#include <bits/stdc++.h>
#include "solution.h"
#include <iostream>

using namespace  std;

/* Add the required Helper Function */


int main(){
    Maximum obj;
    vector<int> prices_month1 = {3,3,5,0,0,3,1,4};
    /* Answer : 6 */
    cout<<obj.maxProfit(prices_month1,2)<<endl;
    vector<int> prices_month2 = {1,2,3,4,5};
    
    /* Answer : 4 */
    cout<<obj.maxProfit(prices_month2,2)<<endl;

    vector<int> prices_month3 = {7,6,4,3,1};
    /* Answer : 0 */
    cout<<obj.maxProfit(prices_month3,2);

    return 0;
}

